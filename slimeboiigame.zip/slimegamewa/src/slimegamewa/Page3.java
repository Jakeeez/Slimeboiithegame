package slimegamewa;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

class Page3 extends JFrame implements ActionListener {
    Page1 p1 = new Page1();
//    Page3 p3 = new Page3();
    
    private ImageIcon backs = new ImageIcon(this.getClass().getResource("backbutton.png"));
    private ImageIcon howtos = new ImageIcon(this.getClass().getResource("bg2.jpg"));
    public JButton BackBT = new JButton(backs);
    
    Page3(){
        setLayout(null);
        BackBT.setBounds(500,300,100,100);
        add(BackBT);
        BackBT.setBorder(BorderFactory.createLineBorder(Color.white, 2));
        BackBT.setBackground(Color.WHITE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }
    public void paintComponent(Graphics g) {
        super.paintComponents(g);
        g.drawImage(howtos.getImage(), 0, 0,getWidth(),getHeight(), this);
    }
}

